package rodrigues.adriane.demo.webfluxerrorlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxErrorListApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxErrorListApplication.class, args);
	}

}
