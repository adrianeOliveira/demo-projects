package rodrigues.adriane.demo.webfluxerrorlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxErrorListApplicationTests {

	@Test
	void contextLoads() {
	}

}
